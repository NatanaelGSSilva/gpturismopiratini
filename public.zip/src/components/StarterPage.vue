<template>
  <div>
    <h3>GP Turismo - Página Principal</h3>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
</style>